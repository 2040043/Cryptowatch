package com.cryptowatch.app.interfaces;

import com.cryptowatch.app.models.NewsArticle;

public interface NewsClickListener {
    void onNewsClicked(NewsArticle article);
}
