# Cryptowatch

An Android app for tracking cryptocurrency prices provided by CryptoCompare API

The application is following the MVVM (Model-View-ViewModel) architectural pattern
